'''
Several utils, in particular for experiments
'''
from . import nn